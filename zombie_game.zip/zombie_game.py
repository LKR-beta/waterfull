import pygame
import random
import sys

# Pygame 초기화
pygame.init()

# 화면 설정
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Zombie Game")

# 배경 음악 로드 및 재생
pygame.mixer.music.load('background_music.mp3')
pygame.mixer.music.play(-1)  # 무한 재생

# 이미지 로드 및 크기 조절
player_img = pygame.transform.scale(pygame.image.load('player.png'), (50, 50))
zombie_img = pygame.transform.scale(pygame.image.load('zombie.png'), (50, 50))

# 캐릭터 설정
player_pos = [WIDTH/2, HEIGHT/2]
player_speed = 0.5
player_direction = [0, 0]

# 좀비 설정
zombie_speed = 0.2
zombies = []
zombie_size = 50
zombie_spawn_rate = 3000  # milliseconds
last_zombie_spawn = pygame.time.get_ticks()

# 함수: 충돌 여부 확인
def collision(player_pos, zombie_pos):
    p_x, p_y = player_pos
    z_x, z_y = zombie_pos
    if (z_x >= p_x and z_x < (p_x + player_img.get_width())) or (p_x >= z_x and p_x < (z_x + zombie_img.get_width())):
        if (z_y >= p_y and z_y < (p_y + player_img.get_height())) or (p_y >= z_y and p_y < (z_y + zombie_img.get_height())):
            return True
    return False

# 좀비 소리 로드
zombie_sound = pygame.mixer.Sound('zombie_sound.mp3')

# 게임 루프
while True:
    # 화면 지우기
    screen.fill((255, 255, 255))
    
    # 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        
        # 키보드 이벤트 처리
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player_direction[0] = -1
            elif event.key == pygame.K_RIGHT:
                player_direction[0] = 1
            elif event.key == pygame.K_UP:
                player_direction[1] = -1
            elif event.key == pygame.K_DOWN:
                player_direction[1] = 1
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                player_direction[0] = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                player_direction[1] = 0
    
    # 플레이어 이동
    player_pos[0] += player_direction[0] * player_speed
    player_pos[1] += player_direction[1] * player_speed
    
    # 게임 종료 조건: 플레이어가 화면 밖으로 나갔을 때
    if player_pos[0] < 0 or player_pos[0] > WIDTH or player_pos[1] < 0 or player_pos[1] > HEIGHT:
        pygame.quit()
        sys.exit()
    
    # 좀비 추가 및 좀비 소리 재생
    now = pygame.time.get_ticks()
    if now - last_zombie_spawn > zombie_spawn_rate:
        last_zombie_spawn = now
        zombie_pos = [random.randint(0, WIDTH-zombie_size), random.randint(0, HEIGHT-zombie_size)]
        zombies.append(zombie_pos)
        # 좀비 소리 재생
        zombie_sound.play()
    
    # 좀비 그리기 및 이동
    for zombie_pos in zombies:
        screen.blit(zombie_img, zombie_pos)
        # 좀비가 플레이어에게 이동
        if zombie_pos[0] < player_pos[0]:
            zombie_pos[0] += zombie_speed
        elif zombie_pos[0] > player_pos[0]:
            zombie_pos[0] -= zombie_speed
        if zombie_pos[1] < player_pos[1]:
            zombie_pos[1] += zombie_speed
        elif zombie_pos[1] > player_pos[1]:
            zombie_pos[1] -= zombie_speed
        
        # 충돌 체크
        if collision(player_pos, zombie_pos):
            pygame.quit()
            sys.exit()
    
    # 플레이어 그리기
    screen.blit(player_img, player_pos)
    
    # 화면 업데이트
    pygame.display.update()
